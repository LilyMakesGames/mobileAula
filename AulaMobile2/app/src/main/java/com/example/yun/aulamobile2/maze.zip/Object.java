package com.example.yun.aulamobile2;

import android.graphics.Point;

/**
 * Created by Yun on 23/04/2018.
 */

public class Object {

    public Point position;
    int size;

    public Object(Point position, int size){
        this.position = position;
        this.size = size;
    }
}
