package com.example.yun.aulamobile2;

/**
 * Created by Yun on 19/04/2018.
 */

public interface ICollision {

    public void OnCollision(ICollision col);
}
